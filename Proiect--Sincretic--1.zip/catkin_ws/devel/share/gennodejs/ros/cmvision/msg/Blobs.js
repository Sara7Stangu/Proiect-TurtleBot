// Auto-generated. Do not edit!

// (in-package cmvision.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Blob = require('./Blob.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Blobs {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.image_width = null;
      this.image_height = null;
      this.blob_count = null;
      this.blobs = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('image_width')) {
        this.image_width = initObj.image_width
      }
      else {
        this.image_width = 0;
      }
      if (initObj.hasOwnProperty('image_height')) {
        this.image_height = initObj.image_height
      }
      else {
        this.image_height = 0;
      }
      if (initObj.hasOwnProperty('blob_count')) {
        this.blob_count = initObj.blob_count
      }
      else {
        this.blob_count = 0;
      }
      if (initObj.hasOwnProperty('blobs')) {
        this.blobs = initObj.blobs
      }
      else {
        this.blobs = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Blobs
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [image_width]
    bufferOffset = _serializer.uint32(obj.image_width, buffer, bufferOffset);
    // Serialize message field [image_height]
    bufferOffset = _serializer.uint32(obj.image_height, buffer, bufferOffset);
    // Serialize message field [blob_count]
    bufferOffset = _serializer.uint32(obj.blob_count, buffer, bufferOffset);
    // Serialize message field [blobs]
    // Serialize the length for message field [blobs]
    bufferOffset = _serializer.uint32(obj.blobs.length, buffer, bufferOffset);
    obj.blobs.forEach((val) => {
      bufferOffset = Blob.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Blobs
    let len;
    let data = new Blobs(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [image_width]
    data.image_width = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [image_height]
    data.image_height = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [blob_count]
    data.blob_count = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [blobs]
    // Deserialize array length for message field [blobs]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.blobs = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.blobs[i] = Blob.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.blobs.forEach((val) => {
      length += Blob.getMessageSize(val);
    });
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cmvision/Blobs';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9095431d60142fc813f87d8cc9018af4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    uint32 image_width
    uint32 image_height
    uint32 blob_count
    Blob[] blobs
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: cmvision/Blob
    string name
    uint32 red
    uint32 green
    uint32 blue
    uint32 area
    uint32 x
    uint32 y
    uint32 left
    uint32 right
    uint32 top
    uint32 bottom
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Blobs(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.image_width !== undefined) {
      resolved.image_width = msg.image_width;
    }
    else {
      resolved.image_width = 0
    }

    if (msg.image_height !== undefined) {
      resolved.image_height = msg.image_height;
    }
    else {
      resolved.image_height = 0
    }

    if (msg.blob_count !== undefined) {
      resolved.blob_count = msg.blob_count;
    }
    else {
      resolved.blob_count = 0
    }

    if (msg.blobs !== undefined) {
      resolved.blobs = new Array(msg.blobs.length);
      for (let i = 0; i < resolved.blobs.length; ++i) {
        resolved.blobs[i] = Blob.Resolve(msg.blobs[i]);
      }
    }
    else {
      resolved.blobs = []
    }

    return resolved;
    }
};

module.exports = Blobs;
